﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'fa', {
	title: 'انتخاب رنگ UI',
	preview: 'پیش‌نمایش زنده',
	config: 'این رشته را در فایل config.js خود بچسبانید.',
	predefined: 'مجموعه رنگ از پیش تعریف شده'
});
